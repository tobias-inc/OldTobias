const { Command, Emojis, ClientEmbed, ErrorCommand } = require("../../");

class Daily extends Command {
    constructor(client) {
        super(client, {
            name: "daily",
            description: "Dá os creditos diarios",
            usage: { args: true, argsNeed: true, argsTxt: "<user>", need: "{prefix} {cmd} {args}" },
            category: "Fun",
            cooldown: 3000,
            aliases: ["diario", "pagamento"],
            Permissions: ["EMBED_LINKS"],
            UserPermissions: [],
            devNeed: true,
            needGuild: true
        });
    }

    async run({ message, channel, args }, t, { displayAvatarURL } = this.client.user) {

        coins = args[0]

        await this.client.DatabaseUtils.Daily(user, coins)
        .catch((err) => { throw new ErrorCommand(err) });

        channel.send(`parabens fdp voce ganhou ${coins} hoje`)
    }
}
module.exports = Daily;