module.exports = {
    GuildRepository: require('./GuildRepository.js'),
    UserRepository: require("./UserRepository.js"),
    ComandoRepository: require("./ComandoRepository.js"),
    ClientRepository:  require("./ClientRepository.js")
}