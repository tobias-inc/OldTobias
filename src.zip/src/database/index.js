module.exports = {
    DBWrapper: require("./DBWrapper.js"),
    Repository: require('./Repository.js'),
    MongoDB: require("./mongoose/mongoDB.js")
}