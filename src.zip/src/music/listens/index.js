module.exports = {
    QueueMusic: require("./QueueMusic.js"),
    GuildMusic: require("./GuildMusic.js")
}