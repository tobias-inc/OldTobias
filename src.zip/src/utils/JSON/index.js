module.exports = {
    Aliases: require("./Aliases.json"),
    Errors: require("./Errors.json"),
    Match: require("./RandomMatch.json"),
    Regions: require("./RegionsLang.json"),

    Utils: require("./Utils.json")
}
